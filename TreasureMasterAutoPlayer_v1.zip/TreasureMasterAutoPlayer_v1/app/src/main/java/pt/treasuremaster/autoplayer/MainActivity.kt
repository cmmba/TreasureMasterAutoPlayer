package pt.treasuremaster.autoplayer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "TREASURE MASTER\nAUTO PLAYER v1.0"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Primeiro protótipo: painel flutuante.\nA deteção visual e os lançamentos automáticos ainda não estão implementados."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val permission = Button(this).apply {
            text = "1. Permitir sobreposição"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    text = "Sobreposição autorizada"
                }
            }
        }
        val start = Button(this).apply {
            text = "2. Mostrar painel no jogo"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    info.text = "Primeiro autoriza a sobreposição nas definições do Android."
                } else {
                    startService(Intent(this@MainActivity, FloatingPanelService::class.java))
                    info.text = "Painel iniciado. Abre o Treasure Master para o veres por cima do jogo."
                }
            }
        }
        layout.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(info)
        layout.addView(permission)
        layout.addView(start)
        setContentView(layout)
    }
}
