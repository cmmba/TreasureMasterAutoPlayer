package pt.treasuremaster.autoplayer

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xEE17333B.toInt())
        }
        val heading = TextView(this).apply {
            text = "TM AUTO PLAYER"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val state = TextView(this).apply {
            text = "PAINEL PRONTO"
            textSize = 12f
            setTextColor(0xFFB8F5D2.toInt())
        }
        val start = Button(this).apply {
            text = "AUTO PLAY (em teste)"
            isEnabled = false
        }
        val stop = Button(this).apply {
            text = "FECHAR PAINEL"
            setOnClickListener { stopSelf() }
        }
        box.addView(heading)
        box.addView(state)
        box.addView(start)
        box.addView(stop)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 140
        }
        windowManager.addView(box, params)
        panel = box
    }

    override fun onDestroy() {
        panel?.let { windowManager.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
