plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "pt.treasuremaster.autoplayer"
    compileSdk = 35
    defaultConfig {
        applicationId = "pt.treasuremaster.autoplayer"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
